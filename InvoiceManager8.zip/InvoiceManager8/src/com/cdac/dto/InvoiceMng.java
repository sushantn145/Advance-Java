package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="invoicemng")
public class InvoiceMng {
	@Id
	@GeneratedValue
	@Column(name="serial_no")
	private int serialNo;
	@GeneratedValue 
	@Column(name="invoice_id")
	private int invoiceNo;
	@Column(name="invoice_date")
	private String invoiceDate;
	@Column(name="invoice_time")
	private String invoiceTime;
	@Column(name="customer_name")
	private String customerName;
	@Column(name="address")
	private String customerAddress;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_quantity")
	private float itemQuantity;
	@Column(name="item_price")
	private float itemPrice;
	@Column(name="item_discount")
	private float itemDiscount;
	@Column(name="item_category")
	private String itemCategory;
	
	
	public InvoiceMng() {
		super();
	}

	public InvoiceMng(int invoiceNo) {
		System.out.println("invoice no"+invoiceNo);
		this.invoiceNo = invoiceNo;
	}

	
	public InvoiceMng(int invoiceNo,String itemName) {
		super();
		this.invoiceNo = invoiceNo;
		this.itemName = itemName;
	}

	public int getSerialNo() {
		return serialNo;
	}


	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}


	public InvoiceMng(int serialNo, int invoiceNo, String invoiceDate, String invoiceTime, String customerName,
			String customerAddress, String itemName, float itemQuantity, float itemPrice, float itemDiscount,
			String itemCategory) {
		super();
		this.serialNo = serialNo;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.invoiceTime = invoiceTime;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.itemPrice = itemPrice;
		this.itemDiscount = itemDiscount;
		this.itemCategory = itemCategory;
	}

	
	public int getInvoiceNo() {
		return invoiceNo;
	}

	
	public InvoiceMng(String itemName) {
		this.itemName = itemName;
	}

	public void setInvoiceNo(int invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	public String getInvoiceDate() {
		return invoiceDate;
	}


	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}


	public String getInvoiceTime() {
		return invoiceTime;
	}


	public void setInvoiceTime(String invoiceTime) {
		this.invoiceTime = invoiceTime;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public float getItemQuantity() {
		return itemQuantity;
	}


	public void setItemQuantity(float itemQuantity) {
		this.itemQuantity = itemQuantity;
	}


	public float getItemPrice() {
		return itemPrice;
	}


	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}


	public float getItemDiscount() {
		return itemDiscount;
	}


	public void setItemDiscount(float itemDiscount) {
		this.itemDiscount = itemDiscount;
	}


	public String getItemCategory() {
		return itemCategory;
	}


	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}


	@Override
	public String toString() {
		return 	serialNo+" "+invoiceNo + " " + invoiceDate + " " + invoiceTime
				+ " " + customerName + " " + customerAddress + " " + itemName
				+ " " + itemQuantity + " " + itemPrice + " " + itemDiscount
				+ " " + itemCategory ;
	}
	
	
}
