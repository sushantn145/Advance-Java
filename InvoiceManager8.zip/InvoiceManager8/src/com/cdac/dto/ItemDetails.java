package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item")
public class ItemDetails {
	@Id
	@GeneratedValue
	@Column(name="item_id")
	private int itemId;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_quantity")
	private float itemQuantity;
	@Column(name="item_price")
	private float itemPrice;
	@Column(name="item_discount")
	private float itemDiscount;
	@Column(name="item_category")
	private String itemCategory;
	
	public ItemDetails() {
		
	}
	public ItemDetails(int itemId, String itemName, float itemQuantity, float itemPrice, float itemDiscount,
			String itemCategory) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.itemPrice = itemPrice;
		this.itemDiscount = itemDiscount;
		this.itemCategory = itemCategory;
	}
	public ItemDetails(int itemId) {
		super();
		this.itemId = itemId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(float itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	public float getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}
	public float getItemDiscount() {
		return itemDiscount;
	}
	public void setItemDiscount(float itemDiscount) {
		this.itemDiscount = itemDiscount;
	}
	public String getItemCategory() {
		return itemCategory;
	}
	public void setItemCategory(String itemCategory) {
		this.itemCategory = itemCategory;
	}
	@Override
	public String toString() {
		return itemId + " " + itemName + " " + itemQuantity
				+ " " + itemPrice + " " + itemDiscount + " " + itemCategory;
	}
	
	
}
