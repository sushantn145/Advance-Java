package com.cdac.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.dto.Admin;


@Service
public class AdminValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Admin.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Admin admin  = (Admin)target;
		//Login
		if(admin.getAdminName()==null) {
			System.out.println(target);
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailId","emailkey", "EmailId  Required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminPass","passkey", "Password  Required");
			System.out.println("blank space");
		
		}else{
			//Registration
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminName","unmkey", "Admin Name Required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "adminPass","psdkey", "Paaword  Required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailId","emailkey", "EmailId  Required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobNo","mobkey", "MobNo. Required");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender","gndkey", "Select Gender");
		
		
			String email = "[a-zA-Z0-9.#_!]{3,}+@+[a-zA-Z]{3,}+[.]{1}[a-zA-Z]{3}";
			String mob = "[789][0-9]{9}";
			String password = "(?=.*[0-9])(?=.*[A-Z])(?=.*[!@#$&*_.])[a-zA-Z0-9!@#$&*_.]{5,}";
			System.out.println(mob);
			if((!admin.getEmailId().matches(email))) {
				System.out.println(admin.getEmailId().matches(email));
				errors.rejectValue("emailId", "emailkey","Email wrong");
			}else if(!admin.getAdminPass().matches(password)){
				System.out.println(admin.getAdminPass().matches(password));
				errors.rejectValue("adminPass", "passkey","Password wrong");
			}else if(!admin.getMobNo().matches(mob)) {
				System.out.println(admin.getMobNo());
				errors.rejectValue("mobNo", "mobkey","Enter Valid Mob no.");
			}
		}
	}
	
	

}
