package com.cdac.service;

import java.util.List;

import com.cdac.dto.ItemDetails;

public interface ItemDetailsService {
	void addItem(ItemDetails itemDetails);
	void modifyItem(ItemDetails itemDetails);
	void removeItem(int itemId);
	ItemDetails findItem(int itemId);
	List<ItemDetails> selectAll();
	
}
