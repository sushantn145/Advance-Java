package com.cdac.service;

import java.util.List;

import com.cdac.dto.InvoiceMng;


public interface InvoiceMngService {
	void addItem(InvoiceMng invoiceMng,int no);
	void modifyItem(InvoiceMng invoiceMng);
	void removeItem(String itemName);
	List<InvoiceMng> findItem(int invoiceNo);
	
	InvoiceMng selectInvoice(int serialNo);
	List<InvoiceMng> selectAll();
}
