package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.InvoiceMngDao;
import com.cdac.dto.InvoiceMng;
import com.cdac.dto.ItemDetails;

@Service
public class InvoiceMngServiceImple implements InvoiceMngService{

	@Autowired
	private InvoiceMngDao invoiceMngDao;
	@Override
	public void addItem(InvoiceMng invoiceMng,int no) {
		invoiceMngDao.insertItem(invoiceMng,no);
	}

	@Override
	public void modifyItem(InvoiceMng invoiceMng) {
		invoiceMngDao.updateItem(invoiceMng);
	}

	@Override
	public void removeItem(String itemName) {
		invoiceMngDao.deleteItem(itemName);
	}

	@Override
	public List<InvoiceMng> findItem(int invoiceNo) {
		return invoiceMngDao.selectItem(invoiceNo);
	}

	@Override
	public List<InvoiceMng> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InvoiceMng selectInvoice(int serialNo) {
		return invoiceMngDao.selectInvoice(serialNo);
	}

}
