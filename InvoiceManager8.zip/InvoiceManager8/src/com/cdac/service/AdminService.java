package com.cdac.service;

import com.cdac.dto.Admin;

public interface AdminService {
	public boolean findAdmin(Admin admin);
	public void addAdmin(Admin admin);
	String forgotPassword(String emailId);
}
