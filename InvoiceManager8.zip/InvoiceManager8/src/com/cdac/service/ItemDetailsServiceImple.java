package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ItemDetailsDao;
import com.cdac.dto.ItemDetails;

@Service
public class ItemDetailsServiceImple implements ItemDetailsService{

	@Autowired
	private ItemDetailsDao itemDetailsDao;
	@Override
	public void addItem(ItemDetails itemDetails) {
		itemDetailsDao.insertItem(itemDetails);
	}

	@Override
	public void modifyItem(ItemDetails itemDetails) {
		itemDetailsDao.updateItem(itemDetails);
	}

	@Override
	public void removeItem(int itemId) {
		itemDetailsDao.deleteItem(itemId);
	}

	@Override
	public ItemDetails findItem(int itemId) {
		return itemDetailsDao.selectItem(itemId);
	}

	@Override
	public List<ItemDetails> selectAll() {
		return itemDetailsDao.selectAll();
	}

	

}
