package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.ItemDetails;

import com.cdac.service.ItemDetailsService;

@Controller
public class ItemDetailsController {

	@Autowired
	private ItemDetailsService itemDetailsService;
	
	@RequestMapping(value="/itemForm.htm")
	public String addItemForm(ModelMap map) {
		map.put("itemDetails", new ItemDetails());
		return "item";
	}
	
	@RequestMapping(value="/item.htm",method = RequestMethod.POST)
	public String itemAdd(ItemDetails itemDetails,ModelMap map,HttpSession session) {
		itemDetailsService.addItem(itemDetails);
		return "item";
	}

	@RequestMapping(value="/item_update.htm",method = RequestMethod.GET)
	 public String updateform(@RequestParam int itemId ,ModelMap map,HttpSession session) {
		ItemDetails itemDetails = itemDetailsService.findItem(itemId); 
		System.out.println("Find Item");
		System.out.println(itemDetails);
		map.put("itemDetails", itemDetails);
		return "item_update_form";
	}
	
	@RequestMapping(value="/item_update_formUpdate.htm",method = RequestMethod.POST)
	public String updateItem(ItemDetails itemDetails,ModelMap map,HttpSession session) {
		System.out.println("Select All List");
		System.out.println(itemDetails);
		itemDetailsService.modifyItem(itemDetails);
		
		List<ItemDetails> li = itemDetailsService.selectAll();
		map.put("itemlist", li);
		return "item_list";
	}
	
	
	
	
	@RequestMapping(value="/delete_item.htm",method = RequestMethod.GET)
	public String deleteItem(@RequestParam int itemId,ModelMap map,HttpSession session) {
		itemDetailsService.removeItem(itemId);
		List<ItemDetails> li = itemDetailsService.selectAll();
		map.put("itemlist", li);
		return "item_list";
	}
	
	
	
	@RequestMapping(value = "/itemList.htm",method=RequestMethod.GET)
	public String selectItemForm(ModelMap map) {
		List<ItemDetails> li  = itemDetailsService.selectAll();
		map.put("itemlist",li);
		return "item_list";
	}
	
	@RequestMapping(value="/bill_form.htm",method = RequestMethod.GET)
	public String prepBillForm(ModelMap map) {
		
		return "ToDoList";
	}
	
	
}
