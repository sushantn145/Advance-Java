package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.InvoiceMng;
import com.cdac.dto.ItemDetails;
import com.cdac.service.InvoiceMngService;
import com.cdac.service.ItemDetailsService;


@Controller
public class InvoiceMngController {
	
	@Autowired
	private InvoiceMngService invoiceMngService;
	
	@Autowired
	private ItemDetailsService itemDetailsService;
			static int no = 0;
	
	
	@RequestMapping(value="/insert_Invoice_Item.htm",method = RequestMethod.GET)
		public String prepRegForm(ModelMap map,HttpSession session) {
			no++;
			System.out.println(no);
			map.put("invoiceMng", new InvoiceMng());
			System.out.println(no);
			InvoiceMng invoiceMng = new InvoiceMng(no);
			System.out.println(no);
		return "ToDoList";
	}

	@RequestMapping(value="/invoiceInsert.htm",method = RequestMethod.POST)
	 public String prepInsertInvoice(InvoiceMng invoiceMng,ModelMap map,HttpSession session) {
		System.out.println("==========================");
		 System.out.println(invoiceMng);
		 System.out.println("==========================");
		 System.out.println(invoiceMng.getItemName());
		 System.out.println("==========================");
		 
	
		 
//		 int i = invoiceMng.getInvoiceNo();
//		 System.out.println(i);
//		 invoiceMng.setInvoiceNo(i);
		 invoiceMngService.addItem(invoiceMng, no);
		 System.out.println(invoiceMng.getInvoiceNo());
		 session.setAttribute("invoiceMng", invoiceMng);
		 return "ToDoList";
		}
	

	@RequestMapping(value="/prep_Show_List.htm",method = RequestMethod.GET)
	public String prepShowList(InvoiceMng invoiceMng,ModelMap map,HttpSession session) {
		System.out.println("Show controller");
		List<InvoiceMng> li = invoiceMngService.findItem(no);
		session.setAttribute("invoiceNo", no);
		map.put("InvoiceMng", li);
		return "invoice_list";
	}
	
	@RequestMapping(value="/delete_invoice_item.htm",method = RequestMethod.GET)
	public String deleteInvoiceItem(@RequestParam String itemName,ModelMap map,HttpSession session) {
		System.out.println(itemName);
		invoiceMngService.removeItem(itemName);
		session.setAttribute("itemName", itemName);
		System.out.println("deleted");
		List<InvoiceMng> li = invoiceMngService.findItem(no);
		map.put("InvoiceMng", li);
		return "invoice_list";
	}
	
	@RequestMapping(value="/update_invoice.htm",method = RequestMethod.GET)
	public String prep_update_form(InvoiceMng invoiceMng,@RequestParam int serialNo,ModelMap map,HttpSession session) {
		System.out.println("Hello");
		invoiceMng=invoiceMngService.selectInvoice(serialNo);
		System.out.println(invoiceMng);
		System.out.println("Selected");
		//System.out.println(invoiceMng);
		session.setAttribute("serialNo", serialNo);
		map.put("InvoiceMng", invoiceMng);
		return "update_invoice";
	}
	
	@RequestMapping(value="/update_invoice_form.htm",method = RequestMethod.POST)
	public String updateInvoice(InvoiceMng invoiceMng,ModelMap map,HttpSession session) {
		System.out.println("update contoller");
		
		int serialNo = (int) session.getAttribute("serialNo");
		System.out.println("In controller === "+serialNo);
		
		invoiceMng.setSerialNo(serialNo);
		int i = invoiceMng.getInvoiceNo();
		invoiceMngService.modifyItem(invoiceMng);
		
		List<InvoiceMng> li = invoiceMngService.findItem(i);
		
		session.setAttribute("invoiceMng", li);
		map.put("InvoiceMng", li);
		return "invoice_list";
	}
	
}
