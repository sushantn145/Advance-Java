
package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.ItemDetails;

@Repository
public class ItemDetailsImple implements ItemDetailsDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Override
	public void insertItem(ItemDetails itemDetails) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			
			
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				// TODO Auto-generated method stub
				System.out.println(itemDetails);
				Transaction tr = session.beginTransaction();
				session.save(itemDetails);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}

	@Override
	public void updateItem(ItemDetails itemDetails) {
		// TODO Auto-generated method stub
	 
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
			 Transaction tr = session.beginTransaction();
			 ItemDetails itd = (ItemDetails)session.get(ItemDetails.class, itemDetails.getItemId());
			 
			 System.out.println(itd);
			 itd.setItemName(itemDetails.getItemName());
			 itd.setItemQuantity(itemDetails.getItemQuantity());
			 itd.setItemPrice(itemDetails.getItemPrice());
			 itd.setItemCategory(itemDetails.getItemCategory());
			 itd.setItemDiscount(itemDetails.getItemDiscount());
			 tr.commit();
			 session.flush();
			 session.close();
			 return null;
			}
		});
	}

	@Override
	public void deleteItem(int itemId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new ItemDetails(itemId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}

	@Override
	public ItemDetails selectItem(int itemId) {
		ItemDetails itmlist = hibernateTemplate.execute(new HibernateCallback<ItemDetails>() {

			@Override
			public ItemDetails doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				ItemDetails itmdtl = (ItemDetails) session.get(ItemDetails.class, itemId);
				tr.commit();
				session.flush();
				session.close();
				return itmdtl;
			}
		});
		return itmlist;
	}

	@Override
	public List<ItemDetails> selectAll() {
		// TODO Auto-generated method stub
		List<ItemDetails> list = hibernateTemplate.execute(new HibernateCallback<List<ItemDetails>>() {

			@Override
			public List<ItemDetails> doInHibernate(Session session) throws HibernateException {
				// TODO Auto-generated method stub
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from ItemDetails");
				List<ItemDetails> li = q.list();
				System.out.println(li);
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}


}
