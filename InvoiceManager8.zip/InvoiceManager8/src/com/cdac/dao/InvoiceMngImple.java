package com.cdac.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.InvoiceMng;
import com.cdac.dto.ItemDetails;
import com.cdac.service.ItemDetailsService;

@Repository
public class InvoiceMngImple implements InvoiceMngDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Autowired
	private ItemDetailsService itemDetailsService;
	@Override
	public void insertItem(InvoiceMng invoiceMng,int no) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			
			
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				// TODO Auto-generated method stub
				System.out.println(invoiceMng);
				Transaction tr = session.beginTransaction();
				invoiceMng.setInvoiceNo(no);
				System.out.println(no);
				session.save(invoiceMng);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}

	@Override
	public void updateItem(InvoiceMng invoiceMng) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
			 Transaction tr = session.beginTransaction();			 
			 System.out.println("serial no = "+invoiceMng.getSerialNo());
			 int serialNo = invoiceMng.getSerialNo();
			 Query q = session.createQuery("update InvoiceMng set customerName=? ,customerAddress=?,itemName=?,itemQuantity=?,itemPrice=?,itemDiscount=?,itemCategory=? where serialNo= "+serialNo);
			 System.out.println(q);
			 System.out.println(invoiceMng.getCustomerName());
			 q.setString(0, invoiceMng.getCustomerName());
			 q.setString(1, invoiceMng.getCustomerAddress());
			 q.setString(2, invoiceMng.getItemName());
			 q.setFloat(3, invoiceMng.getItemQuantity());
			 q.setFloat(4, invoiceMng.getItemPrice());
			 q.setFloat(5, invoiceMng.getItemDiscount());
			 q.setString(6, invoiceMng.getItemCategory());
			
			 int i = q.executeUpdate();
			 System.out.println(i+" rows affected");
			 tr.commit();
			 session.flush();
			 session.close();
			 return null;
			}
		});
	}

	@Override
	public void deleteItem(String itemName) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println("Printing");
				System.out.println(itemName);
				Query q = session.createQuery("delete from InvoiceMng where itemName = ?");
				q.setString(0, itemName);
				int i = q.executeUpdate();
				System.out.println(i+" row affetced");
				System.out.println("delete");
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});		
	}
	@Override
	public List<InvoiceMng> selectItem(int invoiceNo) {
		List<InvoiceMng> list = hibernateTemplate.execute(new HibernateCallback<List<InvoiceMng>>() {

			@Override
			public List<InvoiceMng> doInHibernate(Session session) throws HibernateException {
				// TODO Auto-generated method stub
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from InvoiceMng where invoiceNo = ?");
				q.setInteger(0, invoiceNo);
				List<InvoiceMng> li = q.list();
				System.out.println(li);
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}

	@Override
	public List<InvoiceMng> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InvoiceMng selectInvoice(int serialNo) {
     InvoiceMng invmglt = hibernateTemplate.execute(new HibernateCallback<InvoiceMng>() {

			@Override
			public InvoiceMng doInHibernate(Session session) throws HibernateException {
			    Transaction tr = session.beginTransaction();
			    System.out.println("serial No " +serialNo);
			    InvoiceMng invmnglt = (InvoiceMng) session.get(InvoiceMng.class,serialNo);
				tr.commit();
				session.flush();
				session.close();
				return invmnglt;
			}
		});
		return invmglt;
	}
}