package com.cdac.dao;

import com.cdac.dto.Admin;


public interface AdminDao {
	boolean checkAdmin(Admin admin);
	void insertAdmin(Admin admin);
	String forgotPassword(String emailId);
}
