package com.cdac.dao;

import java.util.List;

import com.cdac.dto.InvoiceMng;
import com.cdac.dto.ItemDetails;

public interface InvoiceMngDao {
	void insertItem(InvoiceMng invoiceMng,int no);
	void updateItem(InvoiceMng invoiceMng);
	void deleteItem(String itemName);
	List<InvoiceMng> selectItem(int invoiceNo);
	
	InvoiceMng selectInvoice(int serialNo);
	List<InvoiceMng> selectAll();
}
