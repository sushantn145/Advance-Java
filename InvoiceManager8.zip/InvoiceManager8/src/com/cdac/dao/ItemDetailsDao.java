package com.cdac.dao;

import java.util.List;

import com.cdac.dto.ItemDetails;

public interface ItemDetailsDao {
	void insertItem(ItemDetails itemDetails);
	void updateItem(ItemDetails itemDetails);
	void deleteItem(int itemId);
	ItemDetails selectItem(int itemId);
	List<ItemDetails> selectAll();
}
